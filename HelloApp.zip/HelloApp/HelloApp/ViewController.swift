//
//  ViewController.swift
//  HelloApp
//
//  Created by Butham,Sanjay Kumar on 1/20/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    @IBOutlet weak var gradeOutlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func ButtonClicked(_ sender: UIButton) {
        //read the text from the text field and store in variable
        var name = nameOutlet.text!
        var grade = gradeOutlet.text!
        //assign the text to display label in this format,Hello name!
        displayLabel.text = "Hello , \(name)! and your grade is \(grade)"
        
        
    }
}

